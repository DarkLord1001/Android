package com.example.q11;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

/*
 11.	Create following Vertical Scroll View Creation in Android
*/
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}