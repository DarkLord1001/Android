package com.example.as6_32email_send;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText To;
    private EditText Subject;
    private EditText Message;
    private Button SendEmail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        To = findViewById(R.id.editTextTo);
        Subject = findViewById(R.id.editTextSubject);
        Message = findViewById(R.id.editTextMessage);

        SendEmail = findViewById(R.id.buttonSend);

        String StringTo = To.getText().toString().trim();
        String StringSubject = Subject.getText().toString().trim();
        String StringMessage = Message.getText().toString().trim();

        SendEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.setType("text/plain");
                emailIntent.putExtra(Intent.EXTRA_EMAIL,new String[]{StringTo});
                emailIntent.putExtra(Intent.EXTRA_SUBJECT,StringSubject);
                emailIntent.putExtra(Intent.EXTRA_TEXT,StringMessage);

                startActivity(Intent.createChooser(emailIntent,"Send Email"));
            }
        });


    }
}